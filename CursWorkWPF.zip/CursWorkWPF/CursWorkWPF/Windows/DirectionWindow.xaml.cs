﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CursWorkWPF.Windows
{
    /// <summary>
    /// Логика взаимодействия для Direction.xaml
    /// </summary>
    public partial class Direction : Window
    {
        public Direction()
        {
            InitializeComponent();
        }

        private void addDirection_Click(object sender, RoutedEventArgs e)
        {
            using (Models.CursWorkForWPFEntities3 db = new Models.CursWorkForWPFEntities3())
            {
                Models.nameDirections nameDirection = new Models.nameDirections()
                {
                    nameDirection = newDirection.Text
                };
                db.nameDirections.Add(nameDirection);
                db.SaveChanges();
            }
        }
    }
}
