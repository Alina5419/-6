﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CursWorkWPF.Windows
{
    /// <summary>
    /// Логика взаимодействия для AdminTeamLeader.xaml
    /// </summary>
    public partial class AdminTeamLeader : Window
    {
        public AdminTeamLeader()
        {
            InitializeComponent();
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            var deletehotel = DBGridModel.SelectedItems.Cast<Models.Applications>().ToList();

            if (MessageBox.Show($"Вы точно хотите удалить следующие {deletehotel.Count()} элемента?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    Models.CursWorkForWPFEntities3.GetContext().Applications.RemoveRange(deletehotel);
                    Models.CursWorkForWPFEntities3.GetContext().SaveChanges();
                    MessageBox.Show("Информация удалена успешно", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                    DBGridModel.ItemsSource = Models.CursWorkForWPFEntities3.GetContext().Applications.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
    }
}
