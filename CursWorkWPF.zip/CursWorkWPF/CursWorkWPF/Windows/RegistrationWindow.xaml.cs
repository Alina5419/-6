﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CursWorkWPF.Windows
{
    /// <summary>
    /// Логика взаимодействия для RegistrationWindow.xaml
    /// </summary>
    public partial class RegistrationWindow : Window
    {
        public RegistrationWindow()
        {
            InitializeComponent();
        }

        private void reg_Click(object sender, RoutedEventArgs e)
        {

            string login = regLoginTB.Text;
            string password = regPasswordTB.Password;

            Models.Guest guest = new Models.Guest();
            guest.loginGuest = login;
            guest.passwordGuest = password;
            guest.roleGuest = yourRole.Text;

            if (login.Length < 5)
            {
                MessageBox.Show("Длина логина должна быть больше 5!");
                return;

            }
            else if (login.Length < 5)
            {
                MessageBox.Show("Длина пароля должна быть больше 5!");
                return;
            }

            else
            {
                Models.Guest authUser = null;
                using (Models.CursWorkForWPFEntities3 db = new Models.CursWorkForWPFEntities3())
                {
                    authUser = db.Guest.Where(b => b.loginGuest == login).FirstOrDefault();
                }
                if (authUser != null)
                {
                    MessageBox.Show("Такой логин или почта уже существует!");
                    return;
                }
                else
                {
                    Models.CursWorkForWPFEntities3.GetContext().Guest.Add(guest);
                    Models.CursWorkForWPFEntities3.GetContext().SaveChanges();
                    MessageBox.Show($"Вы успешно зарегистрировались!");
                    Windows.JoinWindow jW = new JoinWindow();
                    jW.Show();
                    this.Hide();
                }
            }
        }

        private void DoYouHaveAccount_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Вы уверены?", "Создать новый аккаунт", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                MessageBox.Show("Принято, переходим.");
                Windows.JoinWindow jW = new JoinWindow();
                jW.Show();
                this.Hide();
            }
        }
    }
}
