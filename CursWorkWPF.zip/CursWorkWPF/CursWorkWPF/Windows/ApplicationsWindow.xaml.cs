﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CursWorkWPF.Windows
{
    /// <summary>
    /// Логика взаимодействия для ApplicationsWindow.xaml
    /// </summary>
    public partial class ApplicationsWindow : Window
    {
        public ApplicationsWindow()
        {
            InitializeComponent();
            CountryBox.ItemsSource = Models.CursWorkForWPFEntities3.GetContext().Applications.ToList();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            using (Models.CursWorkForWPFEntities3 db = new Models.CursWorkForWPFEntities3())
            {
                var application = new Models.Applications()
                {
                    names = name.Text,
                    surname = surname.Text,
                    direction = CountryBox.Text
                };
                db.Applications.Add(application);
                db.SaveChanges();
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void addRequest_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
