﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CursWorkWPF.Windows
{
    /// <summary>
    /// Логика взаимодействия для Schedule.xaml
    /// </summary>
    public partial class Schedule : Window
    {
        public Schedule()
        {
            InitializeComponent();
        }

        private void GoBackMain_Click(object sender, RoutedEventArgs e)
        {
            using (Models.CursWorkForWPFEntities3 db = new Models.CursWorkForWPFEntities3())
            {
                foreach (var item in db.Guest)
                {
                    if (item.roleGuest == "Администратор")
                    {
                        Windows.AdminWindow aW = new AdminWindow();
                        aW.Show();
                        this.Hide();
                        return;
                    }
                    else if (item.roleGuest == "Преподаватель")
                    {
                        Windows.TeamLeaderWindow aW = new TeamLeaderWindow();
                        aW.Show();
                        this.Hide();
                        return;
                    }
                    else if (item.roleGuest == "Пользователь")
                    {
                        Windows.UserWindow aW = new UserWindow();
                        aW.Show();
                        this.Hide();
                        return;
                    }
                }
            }
        }
    }
}
