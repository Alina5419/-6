﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CursWorkWPF.Windows
{
    /// <summary>
    /// Логика взаимодействия для TeamLeaderWindow.xaml
    /// </summary>
    public partial class TeamLeaderWindow : Window
    {
        public TeamLeaderWindow()
        {
            InitializeComponent();
            DBGridModel.ItemsSource = Models.CursWorkForWPFEntities3.GetContext().Direction.OrderBy(h => h.idDirection);
        }
    }
}
