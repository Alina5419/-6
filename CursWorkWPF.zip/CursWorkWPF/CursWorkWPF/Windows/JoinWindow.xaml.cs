﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CursWorkWPF.Windows
{
    /// <summary>
    /// Логика взаимодействия для JoinWindow.xaml
    /// </summary>
    public partial class JoinWindow : Window
    {
        public JoinWindow()
        {
            InitializeComponent();
        }

        private void join_Click(object sender, RoutedEventArgs e)
        {
            using (Models.CursWorkForWPFEntities3 db = new Models.CursWorkForWPFEntities3())
            {
                foreach(var item in db.Guest)
                {
                    if(joinLoginTB.Text == item.loginGuest && joinPasswordTB.Password == item.passwordGuest)
                    {
                        if (item.roleGuest == "Администратор")
                        {
                            Windows.AdminWindow aW = new AdminWindow();
                            aW.Show();
                            this.Hide();
                            return;
                        }
                        if (item.roleGuest == "Преподаватель")
                        {
                            Windows.TeamLeaderWindow tlW = new TeamLeaderWindow();
                            tlW.Show();
                            this.Hide();
                            return;
                        }
                        if (item.roleGuest == "Пользователь")
                        {
                            MainWindow mW = new MainWindow();
                            mW.Show();
                            this.Hide();
                            return;
                        }
                    }
                }
            }
        }

        private void DoYouHaveAccount_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Вы уверены?", "Создать новый аккаунт", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                MessageBox.Show("Принято, переходим.");
                Windows.RegistrationWindow rW = new RegistrationWindow();
                rW.Show();
                this.Hide();
            }
        }
    }
}
