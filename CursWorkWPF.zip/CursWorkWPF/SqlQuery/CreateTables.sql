create table Administrator
(
	id int identity(1,1) primary key not null,
	FullName nvarchar(100) not null,
	email nvarchar(100) not null
)

create table Applications
(
	id int identity(1,1) primary key not null,
	idUser int null,
	idSelection int null,
	idAdmin int null,
	idTeamLeader int null,
	NameApproved nvarchar(100) null,
	surname nvarchar(100) null,
	names nvarchar(100) null,
	direction nvarchar(100) null
)

create table Guest
(
	id int identity(1,1) primary key not null,
	idAdmin int null,
	idUser int null,
	idTeamLeader int null,
	loginGuest nvarchar(100) not null,
	passwordGuest nvarchar(100) not null,
	roleGuest nvarchar(100) not null
)

create table TeamLeader
(
	idTeamLeader int identity(1,1) primary key not null,
	FullName nvarchar(100) not null,
	email nvarchar(100) not null
)

create table Users
(
	idUser int identity(1,1) primary key not null,
	FullName nvarchar(100) not null,
	email nvarchar(100) not null,
	DateOfBirth nvarchar(100) not null
)

create table Direction
(
	idDirection int identity(1,1) primary key not null,
	idTeamLeader int null,
	MemberCount int null
)